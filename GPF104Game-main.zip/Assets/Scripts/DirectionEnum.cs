public enum DirectionEnum
{
    RIGHT,
    DOWN,
    LEFT,
    UP
}