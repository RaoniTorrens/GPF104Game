public enum MovementStateEnum
{
    IDLE,
    FOLLOW,
    ROAM,
    PATROL,
    CHASE
}